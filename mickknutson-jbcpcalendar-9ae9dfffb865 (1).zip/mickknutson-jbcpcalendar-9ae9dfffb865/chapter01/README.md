# README #

### Anatomy of an Unsafe Application ###

Baseline application


Running the project
-
to run each project in this chapter, run the following command from the milestone directory:

./gradlew[.bat] tomcatRun

then open a browser to:

[http://localhost:8080/calendar](http://localhost:8080/calendar)


#### 01.00-calendar ####
Base line Starting from chapter01.00


