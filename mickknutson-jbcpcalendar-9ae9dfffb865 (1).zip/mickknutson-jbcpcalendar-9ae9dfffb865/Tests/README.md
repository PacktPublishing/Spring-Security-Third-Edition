# Spring Security 3rd Edition README

Funtional Test Cases

## Katalon

A new replacement for Selenium IDE

* [Katalon](https://www.katalon.com)

The script in this directory are used to perform some basic functional testing on the JBCP Calendar.

## the end... ##
***