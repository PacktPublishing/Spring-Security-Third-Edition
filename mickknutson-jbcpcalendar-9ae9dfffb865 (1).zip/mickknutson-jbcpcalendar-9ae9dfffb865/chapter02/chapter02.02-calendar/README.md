
The page isn't redirecting properly
-
This is intentional

If you have not already, restart the application and visit http://localhost:8080 in Firefox; you will see an error, as shown in the following screenshot: